﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Temporizador : MonoBehaviour
{
    // Declaração das variáveis.
    public Text txtTemporizador;
    private float temporizador;
    public static Temporizador temp;

    // Método chamado quando o objeto é instanciado.
    private void Awake()
    {
        // Inicializando a variável em 120 segundos.
        temporizador = 120f;
    }

    // Método chamado quando o script é solicitado.
    private void Start()
    {
        // Se a variável "temp" estiver vazia.
        if (Temporizador.temp == null)
        {
            // É solicitado que seja definido algo.
            temp = gameObject.GetComponent<Temporizador>();
        }
        
        // Impede que um objeto que possuí a tag de "Relogio" seja destruído.
        DontDestroyOnLoad(GameObject.FindGameObjectWithTag("Relogio"));
    }

    // Método chamado a cada frame do jogo.
    private void Update()
    {
        // Decrementa o valor do tempo a cada frame.
        temporizador -= Time.deltaTime;

        // Regra para definir o texto do tempo em segundos.
        txtTemporizador.text = temporizador.ToString("F");
    }

    // Muda o temporizador
    public void SetTemporizador(float c)
    {
        temporizador = c;
    }

    // Retorna o temporizador
    public float GetTemporizador()
    {
        return temporizador;
    }
}
