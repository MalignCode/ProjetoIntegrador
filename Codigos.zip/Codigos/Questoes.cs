﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Questoes : MonoBehaviour
{
    // Textos que serão mostrados nas questçoes de correçção de código
    public static string q12 =

        "public class Hora { " + "\n" +


        "\n" +

        "private String horario; " + "\n" +
        "int horaPeriodo " + "\n" +


        "\n" +


        "public float getHorario() {" + "\n" +
           "return horario; " + "\n" +
        "} " + "\n" +


        "\n" +



        "public int setHorario(int horas, int minutos, int segundos) " + "\n" +

        "\n" +

           "horaPeriodo = horas; " + "\n" +
        "this.horario = horas : minutos : segundos " + "\n" +
        "} " + "\n" +

        "\n" +

        "public void toString() {" + "\n" +
           "return this.horario; " + "\n" +

        "\n" +

        "public void periodo() { " + "\n" +
          "if (horaPeriodo >= 18) {" + "\n" +
          "System.out.println(Eh noite!);" + "\n" +
        "} " + "\n" +
        "else {" + "\n" +
           "System.out.println(Eh dia!)" + "\n" +
        "} " + "\n" +
        "\n" +
        "} " + "\n" +
        "\n" +
        "} ";





    public static string q2 = 
        "public class Computador {" + "\n" +
        "\n" +

        "int memoriaRAM;" + "\n" +
        "int tamanhoHD;" + "\n" +
        "float velocCPU;" + "\n" +
        "\n" +

        "public void mostrarInfoSistema() {" + "\n" +

        "\n" +
           "System.out.println(\"Memoria: \" + memoriaRAM);" + "\n" +
           "System.out.println(\"HD: \" + tamanhoHD);" + "\n" +
           "System.out.println(\"Velocidade: \" + velocCPU);" + "\n" +
        "\n" +

        "}" + "\n" +

        "\n" +

        "public void ligar()" + "\n" +
        "{" + "\n" +
        "\n" +
        "}" + "\n" +


        "\n" +


        "public void reiniciar()" + "\n" +
        "{" + "\n" +
        "\n" +
        "}" + "\n" +
        "\n" +


        "public void calcular()" + "\n" +
       "{" + "\n" +
        "\n" +
        "}" + "\n" +
        "\n" +


        "public void imprimir()" + "\n" +
        "{" + "\n" +
        "\n" +
        "}" + "\n" +
        "\n" +


        "public void desligar()" + "\n" +
        "{" + "\n" +
        "\n" +
        "}" + "\n" +
        "\n" +
    "}";

     public static string q3 =

         "public class Circulo  { " + "\n" +
        "\n" +
         "private float circunferencia;" + "\n" +
         "private int raio;" + "\n" +
        "\n" +
         "}";



     public static string q26 = 

         "public class Cachorro  {" + "\n" +

        "\n" +

         "private String raca;" + "\n" +

        "\n" +

         "public void String getRaca() {" + "\n" +
            "raca;" + "\n" +
         "}" + "\n" +

        "\n" +

         "public float setRaca(int raca) {" + "\n" +
            "this.raca = raca;" + "\n" +
         "return raca;" + "\n" +
         "}" + "\n" +

        "\n" +

         "}";


}
