﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu: MonoBehaviour
{
    // Declaração de variáveis.
    private GameObject resultado;

    // Método chamado quando o script é solicitado.
    void Start()
    {
        // Variável resultado recebendo um objeto com tag de "Player".
        resultado = GameObject.FindGameObjectWithTag("Player");
    }

    // Método chamado para carregar a cena do parâmetro, e também destruir o objeto "resultado".
    public void CarregaFase(string cena)
    {
        SceneManager.LoadScene(cena);
        Destroy(resultado);
    }

    // Método chamado para fechar o jogo.
    public void Sair()
    {
        Application.Quit();
    }
}
