﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dados: MonoBehaviour
{
    // Declaração das variáveis.
    public GameObject[] Personagem;
    public static int InstanciaPersonagem;

    // Método chamado quando o objeto é instanciado.
    void Awake()
    {
        // Atribuindo a variável "Personagem" objetos que possuem a tag de "Player".
        Personagem = GameObject.FindGameObjectsWithTag("Player");

        // Impedindo que o objeto seja destruído ao trocar de cena.
        DontDestroyOnLoad(this.transform.gameObject);
    }
}
