﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Resultado : MonoBehaviour
{
    // Declaração das variáveis.
    public Text txtAcerto1, txtAcerto2, txtAcerto3;
    public Text txtErro1, txtErro2, txtErro3;
    public Text Racerto1, Racerto2, Racerto3;
    public Text Rerro1, Rerro2, Rerro3;
    public int acerto1, acerto2, acerto3;
    public int erro1, erro2, erro3;
    public static GameObject resultados;
    public GameObject resultado;
    public static GameObject resultadoP;

    // Método chamado quando o script é solicitado.
    private void Start()
    {
        // Variável resultados recebendo um objeto com nome de "Resultado" que está na ativo na cena. 
        resultados = GameObject.Find("Resultado");

        // Impedindo que o objeto resultados seja destruído ao trocar de cena.
        DontDestroyOnLoad(resultados);

        // Os IFS abaixo verificam se o jogador acertou / errou 1 vez para trocar o texto.

        // IF
        if (txtAcerto1.text == "1")
        {
            Racerto1.text = "Questao";
        }
        // IF
        if (txtAcerto2.text == "1")
        {
            Racerto2.text = "Questao";
        }
        // IF
        if (txtAcerto3.text == "1")
        {
            Racerto3.text = "Questao";
        }
        // IF
        if (txtErro1.text == "1")
        {
            Rerro1.text = "vez";
        }
        // IF
        if (txtErro2.text == "1")
        {
            Rerro2.text = "vez";
        }
        // IF
        if (txtErro3.text == "1")
        {
            Rerro3.text = "vez";
        }

        // A variável "resultadoP" recebe o objeto "resultado".
        resultadoP = resultado;

    }

    // Método chamado a cada frame do jogo.
    private void Update()
    {
        // Verifica a cena que está ativa.
        Scene scene = SceneManager.GetActiveScene();

        // Se o nome da cena for um desses IFS abaixo.

        //IF
        if (scene.name == "MenuPrincipal" || scene.name == "Conceitos")
        {
            // O objeto que contém esse script é destruído.
            Destroy(this.gameObject);
        }
        else
        {
            // O objeto resultados é ativado.
            resultados.SetActive(true);
        }

        //IF
        if (scene.name != "Resultado")

            // Os textos recebem os contadores.
            txtAcerto1.text = acerto1.ToString();
            txtAcerto2.text = acerto2.ToString();
            txtAcerto3.text = acerto3.ToString();

            txtErro1.text = erro1.ToString();
            txtErro2.text = erro2.ToString();
            txtErro3.text = erro3.ToString();
        }
    }
