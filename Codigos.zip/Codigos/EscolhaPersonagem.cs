﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EscolhaPersonagem : MonoBehaviour
{
    // Declaração das variáveis.
    public Texture[] Personagem;
    private int SelecaoAtual;

    // Método chamado quando o script é solicitado.
    void Start()
    {
        SelecaoAtual = 0;
    }

    // O OnGUI é chamado para renderizar e manipular eventos da GUI (Componentes Gráficos).
    void OnGUI()
    {
        // Seleção do persongem e troca de fase.
        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 4, Screen.height / 2 - Screen.height / 2.5f, Screen.width / 2, Screen.height / 1.2f), ""))
        {
            Dados.InstanciaPersonagem = SelecaoAtual;
            Application.LoadLevel("Fase1");
        }

        // IFS Verificando qual foi o item selecionado (escolhido pelo jogador).
        // Dentro de todos ifs existem componentes gráficos gerados pelo própio Unity (utilizamos botões e imagens). Os mesmos são modificados para ficarem organizados na tela.

        // IF
        if (SelecaoAtual == 0)
        {
            GUI.DrawTexture(new Rect(Screen.width / 2 - Screen.width / 4, Screen.height / 2 - Screen.height / 2.5f, Screen.width / 2, Screen.height / 1.2f), Personagem[SelecaoAtual]);
            //mudar selecao
            if (GUI.Button(new Rect(Screen.width / 1.3f, Screen.height / 2.2f, Screen.width / 6.5f, Screen.height / 5), "PROXIMO"))
            {
                SelecaoAtual = SelecaoAtual + 1;
            }
        }
        // IF
        if (SelecaoAtual > 0 && SelecaoAtual < (Personagem.Length - 1))
        {
            GUI.DrawTexture(new Rect(Screen.width / 2 - Screen.width / 4, Screen.height / 2 - Screen.height / 2.2f, Screen.width / 2, Screen.height / 1.2f), Personagem[SelecaoAtual]);
            // Muda a seleção
            if (GUI.Button(new Rect(Screen.width / 1.3f, Screen.height / 2.2f, Screen.width / 6.5f, Screen.height / 5), "PROXIMO"))
            {
                SelecaoAtual = SelecaoAtual + 1;
            }
            if (GUI.Button(new Rect(Screen.width / 13, Screen.height / 2.2f, Screen.width / 6.5f, Screen.height / 5), "ANTERIOR"))
            {
                SelecaoAtual = SelecaoAtual - 1;
            }
        }
        // IF
        if (SelecaoAtual >= (Personagem.Length - 1))
        {
            GUI.DrawTexture(new Rect(Screen.width / 2 - Screen.width / 4, Screen.height / 2 - Screen.height / 2.2f, Screen.width / 2, Screen.height / 1.2f), Personagem[SelecaoAtual]);
            // Muda a seleção
            if (GUI.Button(new Rect(Screen.width / 13, Screen.height / 2.2f, Screen.width / 6.5f, Screen.height / 5), "ANTERIOR"))
            {
                SelecaoAtual = SelecaoAtual - 1;
            }
        }
    }
}
