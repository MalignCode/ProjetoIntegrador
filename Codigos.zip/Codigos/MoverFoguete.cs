﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoverFoguete : MonoBehaviour
{
    // Declaração de variáveis.
    public float velocidade;
    public GameObject obj;

    // Método chamado a cada frame do jogo.
    void Update()
    {
        // Move o objeto que possuir este script em uma velocidade pré definida.
        transform.Translate(Vector2.up * velocidade * Time.deltaTime);
    }
}
