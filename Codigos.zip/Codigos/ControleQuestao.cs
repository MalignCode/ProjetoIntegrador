﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ControleQuestao : MonoBehaviour
{
    // Declaração das variáveis
    public GameObject pergunta;
    public GameObject resposta;
    public GameObject[] questoes;
    private int index;
    public string cena1, cena2, cena3;
    public GameObject btnTrocar;
    public Transform btnPosAtual;
    public Transform btnPosFinal;
    private Vector3 PosicaoParaInstanciar;
    private float RotacaoEmX = -577, RotacaoEmY = -276, RotacaoEmZ = -24.625f;
    public static ControleQuestao controlequestao;
    private GameObject obj;

    // Método chamado quando o objeto é instanciado.
    private void Awake()
    {
        // Variável obj recebendo um objeto com nome de "Questoes f1" que está na ativo na cena. 
        obj = GameObject.Find("Questoes f1");

        //
        pergunta = questoes[0].GetComponentInChildren<Questoes>().gameObject;

        // Impedindo que o objeto obj seja destruido ao trocar de cena.
        DontDestroyOnLoad(obj);
    }

    // Método chamado quando o script é solicitado.
    private void Start()
    {
        // Se a variável "controlequestao" estiver vazia.
        if (ControleQuestao.controlequestao == null)
        {
            // É solicitado que seja definido algo.
            controlequestao = gameObject.GetComponent<ControleQuestao>();
        }
    }

    // Método chamado a cada frame do jogo.
    private void Update()
    {
        // Buscando qual cena está ativa.
        Scene scene = SceneManager.GetActiveScene();

        // Se o nome da cena ativa for "MenuPrincipal" ou "Resultado".
        if (scene.name == "MenuPrincipal" || scene.name == "Resultado")
        {
            // O objeto que contém esse script é destruído.
            Destroy(this.gameObject);
        }
        else
        {
            // Senão o objeto é ativo na cena.
            this.gameObject.SetActive(true);
        }

        // Se o tempo for igual ou menor a 0.
        if (Temporizador.temp.GetTemporizador() <= 0)
        {
            // O inimigo ataca o player.
            Inimigo.inimigo.Atacar();

            //
            questoes[index].SetActive(false);

            //
            if (resposta.activeSelf == true)
            {
                //
                resposta.SetActive(false);

                // Troca a posição do botão.
                btnTrocar.transform.position = btnPosAtual.position;
                btnTrocar.transform.rotation = btnPosAtual.rotation;

                // Rotaciona o botão.
                btnTrocar.transform.Rotate(0, 0, -180);
                btnPosAtual.transform.Rotate(0, 0, -180);
            }

            // Soma +1 no indice;
            index += 1;

            //
            QuestoesPraticas.questaoPratica.SetCod();

            // Se o nome do índice da questão for um desses abaixo.
            if (questoes[index].name == "P6" || questoes[index].name == "P7" || questoes[index].name == "P8" || questoes[index].name == "P9" || questoes[index].name == "P10"
                || questoes[index].name == "P16" || questoes[index].name == "P17" || questoes[index].name == "P18" || questoes[index].name == "P19" || questoes[index].name == "P20" || questoes[index].name == "P21"
                || questoes[index].name == "P24" || questoes[index].name == "P28" || questoes[index].name == "P29" || questoes[index].name == "P30" || questoes[index].name == "CarregaCena")
            {
                //
                resposta.SetActive(false);
                btnTrocar.SetActive(false);

                // Define o tempo para 60 segundos.
                Temporizador.temp.SetTemporizador(60f);

            }
            else
            {
                //
                pergunta = questoes[index].GetComponentInChildren<Questoes>().gameObject;

                //
                resposta.GetComponent<InputField>().text = "";

                //
                btnTrocar.SetActive(true);

                // Define o tempo para 180 segundos.
                Temporizador.temp.SetTemporizador(180f);

            }

            // Se o nome do índice da questão for um desses abaixo.
            if (questoes[index].name == "P11" || questoes[index].name == "P12" || questoes[index].name == "P13" || questoes[index].name == "P15" || questoes[index].name == "P22" ||
                questoes[index].name == "P23" || questoes[index].name == "P25")
            {
                // Define o tempo para 240 segundos.
                Temporizador.temp.SetTemporizador(240f);
            }


            // Se o nome do índice da questão for um desses abaixo.
            if (questoes[index].name == "P2")
            {
                // Há questões de correção de código
                // É colocado texto na interface de resposta para que o jogador possa corrigir os códigos
                resposta.GetComponent<InputField>().text = Questoes.q2;
            }
            if (questoes[index].name == "P3")
            {
                //
                resposta.GetComponent<InputField>().text = Questoes.q3;
            }
            if (questoes[index].name == "P12")
            {
                //
                resposta.GetComponent<InputField>().text = Questoes.q12;
            }
            if (questoes[index].name == "P26")
            {
                //
                resposta.GetComponent<InputField>().text = Questoes.q26;
            }

            //
            questoes[index].SetActive(true);

            // Se o nome do índice da questão for um desses abaixo.
            if (questoes[index].name == "P11")
            {
                // É chamado um método que troca de cena.
                StartCoroutine(CarregaCena(cena1));
            }
            if (questoes[index].name == "P21")
            {
                // É chamado um método que troca de cena.
                StartCoroutine(CarregaCena(cena2));

                // É destruído o objeto que possuí a tag de "Player".
                DestroyObject(GameObject.FindGameObjectWithTag("Player"));
            }
            if (questoes[index].name == "CarregaCena")
            {
                // É chamado um método que troca de cena.
                StartCoroutine(CarregaCena(cena3));

                // 
                Resultado.resultadoP.SetActive(true);

                // O gameObject obj é destruído.
                DestroyObject(obj);
            }
        }
    }

    // Carrega a cena com um intervalo de tempo de 2.5 segundos.
    IEnumerator CarregaCena(string c)
    {
        yield return new WaitForSeconds(2.5f);
        SceneManager.LoadScene(c);
    }

    // Reposição do botão trocar.
    public void ReposicionarBotao()
    {
        // Deixa a interface de resposta escrita invisível
        resposta.SetActive(false);

        // Troca a posição do botão.
        btnTrocar.transform.position = btnPosAtual.position;
        btnTrocar.transform.rotation = btnPosAtual.rotation;

        // Rotacionao o botão.
        btnTrocar.transform.Rotate(0, 0, -180);
        btnPosAtual.transform.Rotate(0, 0, -180);


    }

    // Método para trocar e verificar as questões.
    public void ProximaQuestao(int cod)
    {
        // Se o valor do parâmetro passado for igual a 1.
        if (cod == 1)
        {
            // 
            questoes[index].SetActive(false);

            // Soma +1 no indice;
            index += 1;

            // Se o nome do índice da questão for um desses abaixo.
            if (questoes[index].name == "P11")
            {
                // É chamado um método que troca de cena.
                StartCoroutine(CarregaCena(cena1));
            }
            if (questoes[index].name == "P21")
            {
                // É chamado um método que troca de cena.
                StartCoroutine(CarregaCena(cena2));

                // É destruído o objeto que possuí a tag de "Player".
                DestroyObject(GameObject.FindGameObjectWithTag("Player"));
            }
            if (questoes[index].name == "CarregaCena")
            {
                // É chamado um método que troca de cena.
                StartCoroutine(CarregaCena(cena3));

                //
                Resultado.resultadoP.SetActive(true);

                // O gameObject obj é destruído.
                DestroyObject(obj);
            }

            // Se o nome do índice da questão for um desses abaixo.
            if (questoes[index].name == "P6" || questoes[index].name == "P7" || questoes[index].name == "P8" || questoes[index].name == "P9" || questoes[index].name == "P10"
                || questoes[index].name == "P16" || questoes[index].name == "P17" || questoes[index].name == "P18" || questoes[index].name == "P19" || questoes[index].name == "P20" || questoes[index].name == "P21"
                || questoes[index].name == "P24" || questoes[index].name == "P28" || questoes[index].name == "P29" || questoes[index].name == "P30")
            {
                // 
                resposta.SetActive(false);
                btnTrocar.SetActive(false);

                //
                questoes[index].SetActive(true);

                // Define o tempo para 60 segundos.
                Temporizador.temp.SetTemporizador(60f);
            }
            else
            {
                //
                pergunta = questoes[index].GetComponentInChildren<Questoes>().gameObject;

                //
                resposta.GetComponent<InputField>().text = "";

                //
                btnTrocar.SetActive(true);
                questoes[index].SetActive(true);

                // Define o tempo para 180 segundos.
                Temporizador.temp.SetTemporizador(180f);
            }

            //
            if (questoes[index].name == "P11" || questoes[index].name == "P12" || questoes[index].name == "P13" || questoes[index].name == "P15" || questoes[index].name == "P22" ||
                 questoes[index].name == "P23" || questoes[index].name == "P25")
            {
                // Define o tempo para 240 segundos.
                Temporizador.temp.SetTemporizador(240f);
            }

            // Se o nome do índice da questão for um desses abaixo.
            if (questoes[index].name == "P2")
            {
                // Há questões de correção de código
                // É colocado texto na interface de resposta para que o jogador possa corrigir os códigos
                resposta.GetComponent<InputField>().text = Questoes.q2;
            }
            if (questoes[index].name == "P3")
            {
                //
                resposta.GetComponent<InputField>().text = Questoes.q3;
            }
            if (questoes[index].name == "P12")
            {
                //
                resposta.GetComponent<InputField>().text = Questoes.q12;
            }
            if (questoes[index].name == "P26")
            {
                //
                resposta.GetComponent<InputField>().text = Questoes.q26;
            }
        }
    }

    // Método manipulador do botão.
    public void Trocar()
    {
       //  
       if (pergunta.activeSelf == true)
       {
           //
           pergunta.SetActive(false);
           resposta.SetActive(true);

           // Troca a posição do botão.
           btnTrocar.transform.position = btnPosFinal.position;
           btnTrocar.transform.rotation = btnPosFinal.rotation;

           // Rotaciona o botão.
           btnTrocar.transform.Rotate(0, 0, 180);
           btnPosAtual.transform.Rotate(0, 0, -180);

       }
       else
       {
           //
           pergunta.SetActive(true);
           resposta.SetActive(false);

           // Troca a posição do botão.
           btnTrocar.transform.position = btnPosAtual.position;
           btnTrocar.transform.rotation = btnPosAtual.rotation;
           
           // Rotaciona o botão.
           btnTrocar.transform.Rotate(0, 0, -180);
           btnPosAtual.transform.Rotate(0, 0, -180);
       }
    }
}