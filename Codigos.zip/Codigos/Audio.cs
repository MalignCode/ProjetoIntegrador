﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;

public class Audio : MonoBehaviour
{
    // Definindo o som que será emitido.
    AudioSource audioSource;
  
    // Método chamado quando o script é solicitado.
    void Start()
    {
        // Alocando o som definido ao audio source.
        audioSource = GetComponent<AudioSource>();
        
        // Impedindo que o objeto que contém este script seja destruído ao trocar de cena.
        DontDestroyOnLoad(this.gameObject);
    }

    // Método chamado a cada frame do jogo.
    private void Update()
    {
        // Buscando qual cena está ativa.
        Scene scene = SceneManager.GetActiveScene();

        // Se o nome da fase ativar for "Fase1".
        if (scene.name == "Fase1")
        {
            // O objeto que contém esse script é destruído.
            Destroy(this.gameObject);
        }
    }
}
