﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Destruidor : MonoBehaviour
{
    // Método chamado quando o objeto colide com outro trigger.
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Se o objeto que possuí esse script colidir com um objeto que possuí a tag "Foguete".
        if (collision.tag == "Foguete")
        {
            // O objeto que possuí esse script é destruído, e após isso, o método "Troca" é chamado.
            Destroy(this.gameObject, 1.5f);
            StartCoroutine(Troca());
        }
    }

    // Carrega a cena com um intervalo de tempo de 1 segundo.
    IEnumerator Troca()
    {
        // print utilizado para testes.
        print("Coroutine");
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene("Resultado");

        // Ativa o objeto "resultadoP" na cena.
        Resultado.resultadoP.SetActive(true);
    }
}
