﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrocarCanvas : MonoBehaviour
{
    // Declaração das variáveis.
    public GameObject Canvas1;
    public GameObject Canvas2;
    public GameObject button;

    // Método chamado quando o objeto é instanciado.
    private void Awake()
    {
        // Print utilizado para testes.
        print("Trocar Canvas");
    }

    // Método chamado para trocar o canvas.
    public void Trocar()
    {
        if (Canvas1.activeSelf == true)
        {
            Canvas1.SetActive(false);
            Canvas2.SetActive(true);
        }
    }
}
