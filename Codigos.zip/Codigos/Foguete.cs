﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Foguete : MonoBehaviour
{
    // Declaração de variáveis.
    public static Animator animator;
    public AudioSource audioSource;

    // Método chamado quando o script é solicitado.
    private void Start()
    {
        // Alocando a animação definida na variável "animator".
        animator = gameObject.GetComponent<Animator>();

        // Alocando o som definido ao audio source.
        audioSource = GetComponent<AudioSource>();
    }

    // Método chamado quando o objeto colide com outro trigger.
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Se o objeto que possuí esse script colidir com um objeto que possuí a tag "Terra". 
        if (collision.tag == "Terra")
        {
            // Ativando um trigger, o mesmo chama a animação do foguete explodindo.
            animator.SetTrigger("Explodindo");

            //Destruindo o objeto que contém esse script.
            Destroy(this.gameObject, 1.5f);

            // Chamando o método "Fim", e toca o som definido no audioSource.
            StartCoroutine(Fim());
            audioSource.Play();
        }

        // Se o objeto que possuí esse script colidir com um objeto que possuí a tag "Void".
        if (collision.tag == "Void")
        {
            // Ativando um trigger, o mesmo chama a animação do foguete explodindo.
            animator.SetTrigger("Explodindo");

            //Destruindo o objeto que contém esse script.
            Destroy(this.gameObject, 1.5f);

            // Chamando o método "Fim", e toca o som definido no audioSource.
            StartCoroutine(Fim());
            audioSource.Play();
        }
    }
    // Método que troca a cena depois de 1 segundo, e também ativa o gameObject "resultadoP" na cena.
    IEnumerator Fim()
    {
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene("Resultado");
        Resultado.resultadoP.SetActive(true);
    }
}