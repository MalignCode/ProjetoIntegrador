﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class QuestoesTeoricas : MonoBehaviour
{
    // Declaração de variáveis.
    private int resposta;
    private GameObject obj;

    //
    public void Assinalar(int r)
    {
        // Atribuindo a variável "resposta" o valor do parâmetro.
        resposta = r;
    }

    // Método chamado para verificar qual foi a opção selecionada pelo usuário.
    public void VerificarResposta(int b)
    {
        // Atribuindo a variável "resposta" o valor do parâmetro.
        resposta = b;

        // Verificando qual cena está ativa.
        Scene scene = SceneManager.GetActiveScene();

        // Se o nome da cena for um desses IFS abaixo.

        //IF
        if (scene.name == "Fase1")
        {
            // Se o valor da opção for 1.
            if (resposta == 1)
            {
                // A variável "acerto1" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().acerto1++;

                // A animação de ataque do player é chamada.
                Player.player.GetComponent<Animator>().SetTrigger("Atacando");

                //Chama proxima questão
                ControleQuestao.controlequestao.ProximaQuestao(1);
                resposta = 0;
            }
            else
            {
                // A variável "erro1" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().erro1++;

                // É chamado o ataque do inimigo.
                Inimigo.inimigo.Atacar();
                resposta = 0;
            }
        }

        //IF
        if (scene.name == "Fase2")
        {
            // Se o valor da opção for 1.
            if (resposta == 1)
            {
                // A variável "acerto2" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().acerto2++;

                // A animação de ataque do player é chamada.
                Player.player.GetComponent<Animator>().SetTrigger("Atacando");

                //Chama proxima questão
                ControleQuestao.controlequestao.ProximaQuestao(1);
                resposta = 0;
            }
            else
            {
                // A variável "erro2" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().erro2++;

                // É chamado o ataque do inimigo.
                Inimigo.inimigo.Atacar();
                resposta = 0;
            }
        }

        //IF
        if (scene.name == "Fase3")
        {
            // Atribuindo a variável "obj" um objeto que possuí a tag de "Foguete".
            obj = GameObject.FindWithTag("Foguete");

            // Se o valor da opção for 1.
            if (resposta == 1)
            {
                // A variável "acerto3" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().acerto3++;

                // O foguete é rotacionado para a esquerda.
                obj.transform.eulerAngles = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y, transform.eulerAngles.z - 90);

                // A animação do foguete se movendo é chamada.
                Foguete.animator.GetComponent<Animator>().SetTrigger("Mover");

                //Chama proxima questão
                ControleQuestao.controlequestao.ProximaQuestao(1);
            }
            else
            {
                // A variável "erro3" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().erro3++;

                // O foguete é rotacionado para a direita.
                obj.transform.eulerAngles = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y, transform.eulerAngles.z + 90);

                // A animação do foguete se movendo é chamada.
                Foguete.animator.GetComponent<Animator>().SetTrigger("Mover");
            }
        }
    }
}