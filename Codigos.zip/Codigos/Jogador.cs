﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Jogador : MonoBehaviour
{
    // Declaração de variáveis.
    public float saude;
    private float saudeMax;
    public static Jogador player;
    private Animator animator;
    public Image barraDeVida;
    AudioSource audioSource;

    // Método chamado quando o script é solicitado.
    void Start()
    {
        // Limitando a saude do jogador.
        saudeMax = saude;

        // Alocando a animação definida na variável "animator".
        animator = gameObject.GetComponent<Animator>();

        // Alocando o som definido ao audio source.
        audioSource = GetComponent<AudioSource>();

        // Se o objeto "player" estiver vazio.
        if (Jogador.player == null)
        {
            // É solicitado que seja definido um objeto.
            player = this.GetComponent<Jogador>();

        }
    }

    // Método chamado a cada frame do jogo.
    private void Update()
    {
        // Reduz a barra de vida caso o player a perca
        barraDeVida.rectTransform.sizeDelta = new Vector2(saude / saudeMax * 445.8f, 100);
    }

    // Método chamado quando o objeto é instanciado.
    void Awake()
    {
        // Atribuindo ao vetor todos objetos que possuirem a tag de "Player".
        GameObject[] objs = GameObject.FindGameObjectsWithTag("Player");

        // Se a variável objs possuir mais que um objeto, o resto é destruído.
        if (objs.Length > 1)
        {
            Destroy(this.gameObject);
        }
        
        // Impedindo que o objeto que possuí esse script seja destruído.
        DontDestroyOnLoad(this.gameObject);
    }

    // Método chamado para causar dano no Player.
    public void DanoNoPlayer(int dano)
    {
        // Diminui 1 ponto da vida do Player.
        saude -= dano;
        
        // Ativa um trigger que chama a animação do Inimigo.
        animator.SetTrigger("Dano");

        // Toca o som definido.
        audioSource.Play();

        // Se a vida do player acabar.
        if (saude <= 0)
        {
            // Print para testes.
            print("Morreu");

            // Ativa um trigger que chama a animação do player morrendo e chama o método "Morreu".
            animator.SetTrigger("Morto");
            StartCoroutine(Morreu());
        }
    }

    // Método chamado para destruir o objeto que contém esse script, carregar uma cena e também ativar o objeto "resultadoP".
    IEnumerator Morreu()
    {
        yield return new WaitForSeconds(1f);
        DestroyObject(this.gameObject);
        SceneManager.LoadScene("Resultado");
        Resultado.resultadoP.SetActive(true);
    }
}