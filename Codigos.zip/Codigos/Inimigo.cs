﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inimigo : MonoBehaviour
{
    // Declaração das variáveis.
    private Animator animator;
    public static Inimigo inimigo;
    public GameObject projetil;
    public float forca;
    public Transform saidaProjetil;
    AudioSource audioSource;

    // Método chamado quando o script é solicitado.
    private void Start()
    {
        // Alocando a animação definida na variável "animator".
        animator = gameObject.GetComponent<Animator>();

        // Alocando o som definido ao audio source.
        audioSource = GetComponent<AudioSource>();

        // Se o objeto "inimigo" estiver vazio.
        if (Inimigo.inimigo == null)
        {
            // É solicitado que seja definido um objeto.
            inimigo = gameObject.GetComponent<Inimigo>();
        }
    }

    // Método chamado para chamar o ataque do Player.
    public void DanoNoInimigo()
    {
        // Chama a animação de dano.
        animator.SetTrigger("Dano");

        // Print para testes.
        print("Chamou DanoInimigo");

        // Toca o som definido.
        audioSource.Play();
    }

    // Método chamado para chamar o ataque do Inimigo.
    public void Atacar()
    {
        // Chama a animação de dano.
        animator.SetTrigger("Atacando");

        // Instancia um objeto já pré-definido. 
        GameObject novoTiro = Instantiate(projetil, saidaProjetil.position, saidaProjetil.rotation) as GameObject;
        
        // Adiciona força ao objeto "novoTiro".
        novoTiro.GetComponent<Rigidbody2D>().AddForce(-transform.position * forca, ForceMode2D.Impulse);
    }
}
