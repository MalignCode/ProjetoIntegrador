﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Instanciador : MonoBehaviour
{
    // Declaração das variáveis.
    public Vector3 PosicaoParaInstanciar;
    public float RotacaoEmX, RotacaoEmY, RotacaoEmZ;
    public GameObject[] Players;

    // Método chamado quando o script é solicitado.
    void Start()
    {
        // Instancia o objeto definido pelo usuário, nas posições pré-definidas pelos autores do jogo.
        Instantiate(Players[Dados.InstanciaPersonagem], PosicaoParaInstanciar, Quaternion.Euler(RotacaoEmX, RotacaoEmY, RotacaoEmZ));
    }
}
