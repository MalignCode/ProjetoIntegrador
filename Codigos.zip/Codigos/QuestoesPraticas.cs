﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class QuestoesPraticas : MonoBehaviour {

    // Declaração de variáveis.
    public InputField ifield;
    public static QuestoesPraticas questaoPratica;
    static string respostaDigitada;
    string respostaDigEspac = "";
    static string resposta;
    string respEspac = "";
    public static int cod = 1;
    private GameObject obj;

    // Método chamado quando o script é solicitado.
    private void Start()
    {
        // Inicializando a variável com um valor = 1.
        cod = 1;

        // Se o objeto "questaoPratica" estiver vazio.
        if (QuestoesPraticas.questaoPratica == null)
        {
            // É solicitado que seja definido um objeto.
            questaoPratica = gameObject.GetComponent<QuestoesPraticas>();
        }
    }

    //
    public void SetCod()
    {
        cod += 1;
    }

    // Faz a verificação da resposta
    public void VerificarResposta()
    {

        // buscando o texto digitado pelo usuário
        respostaDigitada = ifield.text;
        respEspac = "";
        respostaDigEspac = "";

        // comprimi a string
        respostaDigitada = respostaDigitada.Replace(" ", "");
        respostaDigitada = respostaDigitada.Replace("\n", "");

        for (int i = 0; i < respostaDigitada.Length; i++)
        {
            respostaDigEspac += respostaDigitada[i].ToString().Trim();
        }


        // busca o arquivo com a resposta
        TextAsset txt = (TextAsset)Resources.Load("RR" + cod, typeof(TextAsset));

        string arquivo = txt.text;

        // comprimi a string do arquivo
        try
        {

            resposta = arquivo;

            resposta = resposta.Replace("\n", "");

            resposta = resposta.Replace(" ", "");

            for (int i = 0; i < resposta.Length; i++)
            {

                respEspac += resposta[i].ToString().Trim();


            }
            
        }
        catch
        {
            // Print utilizado para verificar se o arquivo existe.
            print("Class: QuestoesPraticas: Arquivo nao encontrado");

        }

        // Verificando qual cena está ativa.
        Scene scene = SceneManager.GetActiveScene();

        // Se o nome da cena for um desses IFS abaixo.

        // IF
        if (scene.name == "Fase1")
        {
            // Se a resposta que o usuário digitou estiver igual a Resposta correta.
            if (respostaDigEspac == respEspac)
            {
                // A variável "acerto1" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().acerto1++;

                // A animação de ataque do player é chamada.
                Player.player.GetComponent<Animator>().SetTrigger("Atacando");

                // A questão é trocada.
                ControleQuestao.controlequestao.ProximaQuestao(1);

                //Índice usado na concatenação de string para achar o arquivo
                // aqui é adicionado + 1
                cod += 1;
                
                // O botão é reposicionado.
                ControleQuestao.controlequestao.ReposicionarBotao();
                
                return;

            }
            else
            {
                // A variável "erro1" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().erro1++;

                // É chamado o ataque do inimigo.
                Inimigo.inimigo.Atacar();
                return;
            }
        }

        // IF
        if (scene.name == "Fase2")
        {
            // Se a resposta que o usuário digitou estiver igual a Resposta correta.
            if (respostaDigEspac == respEspac)
            {
                // A variável "acerto2" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().acerto2++;

                // A animação de ataque do player é chamada.
                Player.player.GetComponent<Animator>().SetTrigger("Atacando");

                // O botão é reposicionado.
                ControleQuestao.controlequestao.ProximaQuestao(1);

                //Índice usado na concatenação de string para achar o arquivo
                // aqui é adicionado + 1
                cod += 1;

                // O botão é reposicionado.
                ControleQuestao.controlequestao.ReposicionarBotao();
            }
            else
            {
                // A variável "erro2" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().erro2++;

                // É chamado o ataque do inimigo.
                Inimigo.inimigo.Atacar();
            }
        }

        // IF
        if (scene.name == "Fase3")
        {
            // Atribuindo a variável "obj" um objeto que possuí a tag de "Foguete".
            obj = GameObject.FindWithTag("Foguete");

            // Se a resposta que o usuário digitou estiver igual a Resposta correta.
            if (respostaDigEspac == respEspac)
            {
                // A variável "acerto3" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().acerto3++;

                // O foguete é rotacionado para a esquerda.
                obj.transform.eulerAngles = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y, transform.eulerAngles.z - 90);

                // A animação do foguete se movendo é chamada.
                Foguete.animator.GetComponent<Animator>().SetTrigger("Mover");

                //Índice usado na concatenação de string para achar o arquivo
                // aqui é adicionado + 1
                cod += 1;

                // Chama a próxima questão e reposiciona o botao trocar
                ControleQuestao.controlequestao.ProximaQuestao(1);
                ControleQuestao.controlequestao.ReposicionarBotao();
            }
            else
            {
                // A variável "erro3" soma + 1;
                Resultado.resultados.GetComponent<Resultado>().erro3++;

                // O foguete é rotacionado para a direita.
                obj.transform.eulerAngles = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y, transform.eulerAngles.z + 90);

                // A animação do foguete se movendo é chamada.
                Foguete.animator.GetComponent<Animator>().SetTrigger("Mover");
            }
        }
    }
}
