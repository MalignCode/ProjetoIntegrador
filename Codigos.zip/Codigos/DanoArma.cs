﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DanoArma : MonoBehaviour
{
    // Definindo o som que será emitido.
    public AudioSource audioSource;

    // Método chamado quando o script é solicitado.
    private void Start()
    {
        // Alocando o som definido ao audio source.
        audioSource = GetComponent<AudioSource>();
    }

    // Método chamado quando o objeto colide com outro trigger.
    private void OnTriggerEnter2D(Collider2D outro)
    {
        // print utilizado para testes.
        print("Entrou trigger");

        // Se o objeto que possuí esse script colidir com um objeto que possuí a tag "Player".
        if (outro.tag == "Player")
        {
            // print utilizado para testes.
            print("Entrou if");

            // O inimigo da dano no player.
            Player.player.DanoNoPlayer(1);

            // O objeto que contém esse script é destruído.
            DestroyObject(this.gameObject);
        }

        // Se o objeto que possuí esse script colidir com um objeto que possuí a tag "Inimigo".
        if (outro.tag == "Inimigo")
        {
            // O Player ataca o inimigo.
            Inimigo.inimigo.DanoNoInimigo();

            // Tocando o som.
            audioSource.Play();
        }
    }
}
